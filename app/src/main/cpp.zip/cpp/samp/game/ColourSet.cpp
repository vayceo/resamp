//
// Created by x1y2z on 21.09.2023.
//

#include "ColourSet.h"
