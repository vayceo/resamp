//
// Created by x1y2z on 04.05.2023.
//
#include "game/common.h"
#include "Object.h"
