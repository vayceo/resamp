//
// Created by x1y2z on 19.08.2023.
//

#ifndef LIVERUSSIA_ESOUNDATTACHEDTO_H
#define LIVERUSSIA_ESOUNDATTACHEDTO_H

enum eSoundAttachedTo {
    NONE = 0,
    TOVEHICLE,
    TOPLAYER
};

#endif //LIVERUSSIA_ESOUNDATTACHEDTO_H
