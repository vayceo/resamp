#pragma once
#include "game/common.h"
enum class eWeaponSkill : uint8 {
    POOR,
    STD,  // standard
    PRO,
    COP
};
