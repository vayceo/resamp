//
// Created by x1y2z on 20.11.2023.
//

#pragma once

typedef void *OSFile;

