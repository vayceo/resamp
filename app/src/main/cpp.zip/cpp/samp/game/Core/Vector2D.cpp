//
// Created by x1y2z on 27.04.2023.
//

#include "Vector.h"
#include "Vector2D.h"

CVector2D::CVector2D(const CVector& v3) :
        CVector2D{v3.x, v3.y}
{
}